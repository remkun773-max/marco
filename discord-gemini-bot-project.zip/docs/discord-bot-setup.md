# Discord assistant bot

The server runs the Discord assistant alongside the API. It answers in direct
messages and when mentioned in a server channel. Conversation history is kept
in memory per channel and resets when the server restarts.

## Required secrets

Add these through Replit Secrets:

- `DISCORD_TOKEN` — the bot token from the Discord Developer Portal
- `GEMINI_API_KEY` — your Google Gemini API key

Never put either value in source files or chat messages. After adding or changing
secrets, restart the API Server workflow. Gemini API usage follows Google's
current free-tier quotas and limits; check Google AI Studio for the current terms.
The model defaults to `gemini-2.5-flash`; set `GEMINI_MODEL` if you want to use
another model available to your Google AI Studio key.

## Discord setup

1. Create an application in the Discord Developer Portal and add a bot.
2. On the bot's settings page, enable **Message Content Intent**.
3. Copy or reset the bot token and save it as `DISCORD_TOKEN`.
4. Under OAuth2 URL Generator, select the `bot` scope and grant **View Channels**,
   **Send Messages**, **Read Message History**, and **Send Messages in Threads**.
5. Open the generated invite link and add the bot to your server.

The bot's status is available at `/api/bot/status`. It reports `disabled` while
credentials are missing, `starting` during login, `online` when connected, or
`error` if the Discord login fails.
