import { GoogleGenAI } from "@google/genai";
import {
  ChannelType,
  Client,
  GatewayIntentBits,
  Partials,
  type Message,
} from "discord.js";
import { logger } from "../lib/logger";

const MAX_HISTORY_MESSAGES = 10;
const DISCORD_MESSAGE_LIMIT = 1900;
const MODEL = process.env["GEMINI_MODEL"] ?? "gemini-2.5-flash";
const SYSTEM =
  process.env["BOT_SYSTEM"] ??
  "คุณคือผู้ช่วยในเซิร์ฟเวอร์ Discord ตอบเป็นภาษาเดียวกับผู้ใช้ กระชับ เป็นมิตร";

type ConversationTurn = {
  role: "user" | "assistant";
  content: string;
};

type BotStatus =
  | { status: "disabled"; missingCredentials: string[] }
  | { status: "starting" | "online" }
  | { status: "error"; message: string };

const history = new Map<string, ConversationTurn[]>();
const channelQueues = new Map<string, Promise<void>>();
let botStatus: BotStatus = {
  status: "disabled",
  missingCredentials: ["DISCORD_TOKEN", "ANTHROPIC_API_KEY"],
};

function splitMessage(text: string, limit = DISCORD_MESSAGE_LIMIT): string[] {
  const result: string[] = [];
  let part = "";

  for (const character of text) {
    if (part.length + character.length > limit) {
      result.push(part);
      part = "";
    }
    part += character;
  }

  if (part) result.push(part);
  return result.length ? result : ["..."];
}

function enqueueChannelMessage(
  channelId: string,
  operation: () => Promise<void>,
): Promise<void> {
  const previous = channelQueues.get(channelId) ?? Promise.resolve();
  const current = previous.catch(() => undefined).then(operation);
  channelQueues.set(channelId, current);

  void current.then(
    () => {
      if (channelQueues.get(channelId) === current) {
        channelQueues.delete(channelId);
      }
    },
    () => {
      if (channelQueues.get(channelId) === current) {
        channelQueues.delete(channelId);
      }
    },
  );

  return current;
}

async function respondToMessage(
  message: Message,
  client: Client,
  gemini: GoogleGenAI,
): Promise<void> {
  if (message.author.bot || !client.user) return;

  const isDm = message.channel.type === ChannelType.DM;
  if (!isDm && !message.mentions.has(client.user)) return;

  const prompt =
    message.content
      .replace(new RegExp(`<@!?${client.user.id}>`, "g"), "")
      .trim() || "สวัสดี";

  const channelHistory = history.get(message.channel.id) ?? [];
  channelHistory.push({
    role: "user",
    content: `${message.author.displayName}: ${prompt}`,
  });
  while (channelHistory.length > MAX_HISTORY_MESSAGES) {
    channelHistory.shift();
  }
  while (channelHistory.length > 0 && channelHistory[0]?.role !== "user") {
    channelHistory.shift();
  }
  history.set(message.channel.id, channelHistory);

  try {
    if (
      "sendTyping" in message.channel &&
      typeof message.channel.sendTyping === "function"
    ) {
      await message.channel.sendTyping();
    }
    const response = await gemini.models.generateContent({
      model: MODEL,
      contents: channelHistory.map((turn) => ({
        role: turn.role === "assistant" ? "model" : "user",
        parts: [{ text: turn.content }],
      })),
      config: {
        systemInstruction: SYSTEM,
        maxOutputTokens: 8192,
      },
    });
    const reply = response.text || "...";

    channelHistory.push({ role: "assistant", content: reply });

    const parts = splitMessage(reply);
    const firstPart = parts.shift();
    if (firstPart) await message.reply(firstPart);
    for (const part of parts) {
      await message.reply(part);
    }
  } catch (error) {
    if (channelHistory.at(-1)?.role === "assistant") channelHistory.pop();
    if (channelHistory.at(-1)?.role === "user") channelHistory.pop();
    logger.error(
      { err: error, channelId: message.channel.id },
      "Discord assistant reply failed",
    );
    await message
      .reply("ขออภัย มีข้อผิดพลาด ลองใหม่อีกครั้งนะ")
      .catch((replyError: unknown) => {
        logger.warn(
          { err: replyError, channelId: message.channel.id },
          "Could not send the Discord error reply",
        );
      });
  }
}

export function getDiscordBotStatus(): BotStatus {
  return botStatus;
}

export async function startDiscordBot(): Promise<void> {
  const token = process.env["DISCORD_TOKEN"];
  const apiKey = process.env["GEMINI_API_KEY"];
  const missingCredentials = [
    !token && "DISCORD_TOKEN",
    !apiKey && "GEMINI_API_KEY",
  ].filter((key): key is string => Boolean(key));

  if (missingCredentials.length > 0) {
    botStatus = { status: "disabled", missingCredentials };
    logger.warn(
      { missingCredentials },
      "Discord bot is disabled until required secrets are configured",
    );
    return;
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
    ],
    partials: [Partials.Channel],
  });
  const gemini = new GoogleGenAI({ apiKey });

  botStatus = { status: "starting" };
  client.once("ready", () => {
    botStatus = { status: "online" };
    logger.info({ botUser: client.user?.tag }, "Discord bot is online");
  });
  client.on("messageCreate", (message) => {
    void enqueueChannelMessage(message.channel.id, () =>
      respondToMessage(message, client, gemini),
    ).catch((error: unknown) => {
      logger.error(
        { err: error, channelId: message.channel.id },
        "Discord message handler failed",
      );
    });
  });
  client.on("error", (error) => {
    logger.error({ err: error }, "Discord client error");
  });

  try {
    await client.login(token);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "";
    botStatus = {
      status: "error",
      message: errorMessage.includes("disallowed intents")
        ? "Enable Message Content Intent in the Discord Developer Portal."
        : "Discord login failed",
    };
    logger.error({ err: error }, "Could not connect the Discord bot");
  }
}
