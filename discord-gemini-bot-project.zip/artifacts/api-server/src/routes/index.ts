import { Router, type IRouter } from "express";
import botStatusRouter from "./bot-status";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(botStatusRouter);

export default router;
