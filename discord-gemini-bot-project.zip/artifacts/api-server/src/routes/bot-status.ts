import { Router, type IRouter } from "express";
import { getDiscordBotStatus } from "../bot/discord";

const router: IRouter = Router();

router.get("/bot/status", (_req, res) => {
  res.json(getDiscordBotStatus());
});

export default router;
