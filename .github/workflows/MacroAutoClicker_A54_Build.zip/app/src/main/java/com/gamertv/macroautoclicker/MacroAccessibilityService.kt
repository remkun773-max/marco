package com.gamertv.macroautoclicker
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
data class P(val x:Float,val y:Float,val d:Long)
class MacroAccessibilityService:AccessibilityService(){
 companion object{var instance:MacroAccessibilityService?=null}
 private val run=AtomicBoolean(false); private val ex=Executors.newSingleThreadExecutor(); val pts=mutableListOf<P>()
 override fun onServiceConnected(){instance=this}; override fun onAccessibilityEvent(e:android.view.accessibility.AccessibilityEvent?){}
 override fun onInterrupt(){}
 fun clear(){synchronized(pts){pts.clear()}}
 fun add(x:Float,y:Float,d:Long){synchronized(pts){pts.add(P(x,y,d))}}
 fun play(){if(run.get())return;val a=synchronized(pts){pts.toList()};if(a.isEmpty())return;run.set(true);ex.execute{try{while(run.get()){for(p in a){if(!run.get())break;Thread.sleep(p.d.coerceAtLeast(50));val path=Path();path.moveTo(p.x,p.y);dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,40)).build(),null,null)}}}finally{run.set(false)}}}
 fun stop(){run.set(false)}
 override fun onDestroy(){stop();ex.shutdownNow();instance=null;super.onDestroy()}
}
