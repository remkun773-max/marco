package com.gamertv.macroautoclicker
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
class MainActivity: androidx.appcompat.app.AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(32,40,32,24)
  fun btn(t:String, f:()->Unit)=Button(this).apply{text=t;setOnClickListener{f()}}
  l.addView(TextView(this).apply{text="Macro Auto Clicker";textSize=26f})
  l.addView(TextView(this).apply{text="เปิด Accessibility และสิทธิ์แสดงทับแอปอื่นก่อนใช้งาน"})
  l.addView(btn("เปิด Accessibility"){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))})
  l.addView(btn("อนุญาตแสดงทับแอปอื่น"){if(!Settings.canDrawOverlays(this))startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))})
  l.addView(btn("เริ่มปุ่มลอย"){startService(Intent(this,MacroOverlayService::class.java))})
  l.addView(btn("ปิดปุ่มลอย"){stopService(Intent(this,MacroOverlayService::class.java))})
  setContentView(l)
 }
}
