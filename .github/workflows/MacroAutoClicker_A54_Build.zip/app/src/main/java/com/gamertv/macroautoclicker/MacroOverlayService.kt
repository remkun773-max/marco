package com.gamertv.macroautoclicker
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.os.SystemClock
import android.view.*
import android.widget.*
class MacroOverlayService:Service(){
 lateinit var wm:WindowManager; var panel:View?=null; var rec:View?=null; var recording=false; var last=0L
 override fun onBind(i:Intent?):IBinder?=null
 fun params(w:Int,h:Int)=WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
 override fun onCreate(){super.onCreate();wm=getSystemService(WINDOW_SERVICE) as WindowManager;show()}
 fun show(){val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setBackgroundColor(Color.argb(220,30,30,30))
  fun b(t:String,f:()->Unit)=Button(this).apply{text=t;setOnClickListener{f()}}
  box.addView(TextView(this).apply{text="MACRO";setTextColor(Color.WHITE)})
  box.addView(b("Record"){toggle()});box.addView(b("Play"){MacroAccessibilityService.instance?.play()});box.addView(b("Stop"){MacroAccessibilityService.instance?.stop()});box.addView(b("Clear"){MacroAccessibilityService.instance?.clear()})
  panel=box;val p=params(190,WindowManager.LayoutParams.WRAP_CONTENT);p.gravity=Gravity.TOP or Gravity.END;p.x=10;p.y=100;wm.addView(box,p)}
 fun toggle(){if(recording){recording=false;rec?.let{wm.removeView(it)};rec=null;return};MacroAccessibilityService.instance?.clear();recording=true;last=SystemClock.uptimeMillis()
  val v=object:View(this){override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action==MotionEvent.ACTION_DOWN){val n=SystemClock.uptimeMillis();MacroAccessibilityService.instance?.add(e.rawX,e.rawY,(n-last).coerceAtLeast(50));last=n};return true}}
  rec=v;wm.addView(v,params(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT))}
 override fun onDestroy(){rec?.let{wm.removeView(it)};panel?.let{wm.removeView(it)};super.onDestroy()}
}
