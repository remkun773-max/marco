# Macro Auto Clicker — Galaxy A54 5G
โปรเจกต์นี้สร้าง APK จริงด้วย Android build system ไม่ใช่เว็บ index.html

ถ้า AndroidIDE เปิดไม่ได้ ให้ใช้ GitHub Actions:
1. สร้าง GitHub repository
2. อัปโหลดไฟล์ทั้งหมดในโปรเจกต์นี้
3. เปิด Actions > Build APK > Run workflow
4. ดาวน์โหลด Artifact `MacroAutoClicker-A54`
5. แตก ZIP แล้วติดตั้ง `app-debug.apk`
6. เปิด Accessibility และสิทธิ์แสดงทับแอปอื่น

หมายเหตุ: APK นี้เป็น debug build สำหรับทดสอบ
